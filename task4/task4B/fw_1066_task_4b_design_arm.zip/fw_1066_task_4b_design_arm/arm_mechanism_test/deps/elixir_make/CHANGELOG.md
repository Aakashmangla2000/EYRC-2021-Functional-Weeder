# Changelog

## v0.6.3 (2021-10-19)

  * Fallback to `make` if `nmake` is not available on Windows.

## v0.6.2 (2020-12-03)

  * Fix permissions for some files in the repository.

## v0.6.1 (2020-09-07)

  * Warn on paths that contain spaces.
  * Use `gmake` on NetBSD.

## v0.6.0 (2019-06-10)

  * Start tracking CHANGELOG.
