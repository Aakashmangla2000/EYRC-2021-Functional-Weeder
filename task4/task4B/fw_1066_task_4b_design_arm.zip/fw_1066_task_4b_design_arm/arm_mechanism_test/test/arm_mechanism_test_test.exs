defmodule ArmMechanismTestTest do
  use ExUnit.Case
  doctest ArmMechanismTest

  test "greets the world" do
    assert ArmMechanismTest.hello() == :world
  end
end
