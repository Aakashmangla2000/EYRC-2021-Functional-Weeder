defmodule LineFollowerTest do
  use ExUnit.Case
  doctest LineFollower

  test "greets the world" do
    assert LineFollower.hello() == :world
  end
end
