# Changelog

## v0.6.2

  * Fix permissions for some files in the repository.

## v0.6.1

  * Warn on paths that contain spaces.
  * Use `gmake` on NetBSD.

## Before

Before 0.6.1, we didn't have a changelog. Our bad!
