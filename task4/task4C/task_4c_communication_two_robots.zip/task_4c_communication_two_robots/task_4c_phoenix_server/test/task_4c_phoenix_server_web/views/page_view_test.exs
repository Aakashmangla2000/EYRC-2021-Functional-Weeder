defmodule Task4CPhoenixServerWeb.PageViewTest do
  use Task4CPhoenixServerWeb.ConnCase, async: true
end
