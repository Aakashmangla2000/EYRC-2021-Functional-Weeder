defmodule Task4CPhoenixServer.Mailer do
  use Swoosh.Mailer, otp_app: :task_4c_phoenix_server
end
